﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using SharpDX.Direct3D9;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Runtime.CompilerServices;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;

namespace InterestingMovement
{
    public class PacMan : Sprite
    {
        KeyboardHandler inputKeyboard;
        float Rotation;
        public PacMan(Game game):base(game)
        {
            SpriteTexture = "pacmanSingle";
            inputKeyboard = new KeyboardHandler();  
        }

        public void KeyBoardUpdate()
        {
            inputKeyboard.Update();
            //Jump
            if (inputKeyboard.IsHoldingKey(Keys.Up))
            {
                this.Direction = this.Direction + new Vector2(0, -1);
            }
            if (inputKeyboard.IsHoldingKey(Keys.Down))
            {
                this.Direction = this.Direction + new Vector2(0, 1);
            }

            //If keys left or Right key is down acceorate up to make speed
            if (inputKeyboard.IsHoldingKey(Keys.Left))
            {
                this.Direction = this.Direction +new Vector2(-1,0);
            }
            if (inputKeyboard.IsHoldingKey(Keys.Right))
            {
                this.Direction = this.Direction + new Vector2(1,0);
            }
        
        }
        public void UpdateKeepPacmanOnScreen()
        {
            //Keep PacMan On Screen
            if (
            //X right
                (this.Location.X >
                    this.game.GraphicsDevice.Viewport.Width - texture.Width)
                ||
                //X left
                (this.Location.X < 0)
                )
            {
                //Negate X
                this.Direction = this.Direction * new Vector2(0, 0);
            }
            
            if (this.Location.Y > this.game.GraphicsDevice.Viewport.Height-texture.Width || this.Location.Y < 0) 
            {
                this.Direction = this.Direction * new Vector2(0, 0);
            }
        }

        public void UpdateSpeed()
        {
            if (Keyboard.GetState().GetPressedKeys().Length>0)
            {
                this.speed = 25;
            }
            else
            {
                this.speed = 0;
            }
        }

        public override void Update(GameTime gametime)
        {
            UpdateKeepPacmanOnScreen();
            KeyBoardUpdate();
            UpdateSpeed();

            Rotation = (float)System.Math.Atan2(this.Direction.X, this.Direction.Y * -1);
            this.Rotate = (float)MathHelper.ToDegrees(Rotation-(float)(Math.PI/2));
            base.Update(gametime);
        }

    }
}
