﻿
using var game = new InterestingMovement.Game1();
game.Run();
