﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Policy;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TaskbarClock;


namespace InterestingMovement
{
    public class Sprite
    {
        //Vectors
        protected Vector2 Location;
        protected Vector2 Direction;
        protected Vector2 Origin;

        //floats
        protected float time;
        protected float speed;
        protected float Rotate;



        public string SpriteTexture { get; set; }
        public Texture2D texture;

       protected Game game;

        public Sprite(Game game)
        { 
            this.game = game;
        }

        

        public virtual void LoadContent()
        { 
            texture = game.Content.Load<Texture2D>(SpriteTexture);
            this.Location = new Vector2(game.GraphicsDevice.Viewport.Width/2, game.GraphicsDevice.Viewport.Height/2);
            this.Direction = new Vector2(1,0);
            this.Origin = new Vector2(this.texture.Width/2, this.texture.Height/2);
         
        }

        public virtual void timeCorrect()
        {
            this.Location = this.Location + ((this.Direction * this.speed) * (time / 1000));
        }
        public virtual void Update(GameTime gametime)
        {
            time = (float)gametime.ElapsedGameTime.TotalMilliseconds;
            timeCorrect();
        }
        public virtual void Draw(SpriteBatch spritebatch)
        {
            spritebatch.Draw(this.texture, new Rectangle((int)this.Location.X,(int)this.Location.Y,(int)this.texture.Width,(int)this.texture.Height),null,Color.White, MathHelper.ToRadians(this.Rotate),this.Origin,SpriteEffects.None,0);
        }
       
    }
}
